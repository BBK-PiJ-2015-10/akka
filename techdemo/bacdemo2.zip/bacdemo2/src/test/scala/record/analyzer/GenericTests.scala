package record.analyzer

import akka.util.Timeout
import record.analyzer.model.ProcessedRecord

object GenericTests extends App{


  var fucker = Set("a","b","c")

  var prac : Option[String] = None

  prac = Option.apply("alexis")

  println(prac.get)



  //val first = "yasser"
  //val second = "alejandro"
  //val third = "albert"

  ///fucker incl  first

  //fucker = fucker + first

  //fucker += first

  //println(fucker.isEmpty)

  //val times = 22 / 10
  //println(times)

  //fucker.foreach(println)



  //println("fucker")

}
