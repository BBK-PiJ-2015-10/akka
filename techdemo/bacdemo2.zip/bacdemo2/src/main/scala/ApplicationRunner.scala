
import akka.actor.ActorSystem
import akka.camel.CamelExtension
import record.analyzer.state.Coordinator

object ApplicationRunner extends App{

  println("Starting App")
  val sourceAUrl = "localhost:7299/source/a"
  val sourceBUrl = "localhost:7299/source/b"
  val sinkAUrl = "localhost:7299/sink/a"

  val sources = Set(sourceAUrl,sourceBUrl)

  val system = ActorSystem()
  val camel = CamelExtension(system)
  camel.context.start()

  system.actorOf(Coordinator.props(sources,sinkAUrl))

  while(true){

  }
  println("Shutting off App")

}
